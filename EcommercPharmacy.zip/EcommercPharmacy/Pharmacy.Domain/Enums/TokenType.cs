﻿namespace Pharmacy.Domain.Enums;
public enum TokenType
{
    VerificationEmail,
    ResetPassword,
}
