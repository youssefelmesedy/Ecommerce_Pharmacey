﻿using Pharmacy.Application.Services.InterFaces.EntityInterface;

namespace Pharmacy.Application.Services.Implementation.EntityService;
public class OrderItemService : IOrderItemService
{
}
