﻿namespace Pharmacy.Application.Services.InterFaces.EntityInterface;
public interface IOrderItemService
{
}
