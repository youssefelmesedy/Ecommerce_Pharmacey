﻿namespace Pharmacy.Application.Services.InterFaces.EntityInterface;
public interface IOrderService
{
}
