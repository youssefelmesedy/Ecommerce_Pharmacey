﻿namespace Pharmacy.Application.Dtos.Categories;
public class CreateCategoryDto
{
    public string? Name { get; set; }
    public string? Description { get; set; }
}
