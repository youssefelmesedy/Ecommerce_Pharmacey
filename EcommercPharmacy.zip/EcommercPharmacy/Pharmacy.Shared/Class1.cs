﻿namespace Pharmacy.Shared
{
    public class Class1
    {

    }
}
